/* =====================================================================
   CareerIQ - motion layer (small, dependency-free).
   The application itself is R; this file only adds visual effects:
     1. splash screen            5. 3-D tilt + hero spotlight
     2. animated number counters 6. confetti on a strong prediction
     3. sliding sidebar pill     7. direction-aware page transitions
     4. button ripple
   ===================================================================== */
(function () {
  'use strict';

  /* ---------- 1. splash ---------- */
  var splashStart = Date.now();
  function hideSplash() {
    var s = document.getElementById('splash');
    if (!s || s.classList.contains('hide')) return;
    var wait = Math.max(0, 1100 - (Date.now() - splashStart));
    setTimeout(function () { s.classList.add('hide'); setTimeout(function () { s.remove(); }, 900); }, wait);
  }
  document.addEventListener('DOMContentLoaded', function () {
    if (window.jQuery) { jQuery(document).on('shiny:connected', hideSplash); }
    setTimeout(hideSplash, 4500); // fail-safe: never trap the user behind the splash
  });

  /* ---------- 2. counters ---------- */
  var lastVals = {};
  function fmt(v, dec, pre, suf) {
    return pre + Number(v).toLocaleString(undefined, { minimumFractionDigits: dec, maximumFractionDigits: dec }) + suf;
  }
  function animateCount(el) {
    var target = el.getAttribute('data-count');
    if (el.getAttribute('data-cq-done') === target) return;
    var to = parseFloat(target);
    if (isNaN(to)) return;
    var dec = parseInt(el.getAttribute('data-decimals') || '0', 10);
    var pre = el.getAttribute('data-prefix') || '';
    var suf = el.getAttribute('data-suffix') || '';
    var key = el.getAttribute('data-key');
    var has = key && Object.prototype.hasOwnProperty.call(lastVals, key);
    var from = has ? lastVals[key] : 0;
    var dur = has ? 650 : 1500;
    el.setAttribute('data-cq-done', target);
    if (key) lastVals[key] = to;
    var t0 = null;
    function tick(t) {
      if (t0 === null) t0 = t;
      var p = Math.min(1, (t - t0) / dur);
      var e = 1 - Math.pow(1 - p, 4);
      el.textContent = fmt(from + (to - from) * e, dec, pre, suf);
      if (p < 1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }
  function scanCounters(root) {
    if (!root || root.nodeType !== 1) return;
    if (root.hasAttribute && root.hasAttribute('data-count')) animateCount(root);
    if (root.querySelectorAll) root.querySelectorAll('[data-count]').forEach(animateCount);
  }
  document.addEventListener('DOMContentLoaded', function () {
    new MutationObserver(function (muts) {
      muts.forEach(function (m) { m.addedNodes.forEach(scanCounters); });
    }).observe(document.body, { childList: true, subtree: true });
    scanCounters(document.body);
  });

  /* ---------- 3 + 7. sidebar pill and page direction ---------- */
  function moveIndicator() {
    var ul = document.querySelector('.sidebar-menu');
    if (!ul) return;
    var ind = document.getElementById('nav-indicator');
    if (!ind) {
      ind = document.createElement('div');
      ind.id = 'nav-indicator';
      ul.insertBefore(ind, ul.firstChild);
    }
    var act = ul.querySelector('li.active');
    if (act) {
      ind.style.transform = 'translateY(' + act.offsetTop + 'px)';
      ind.style.height = act.offsetHeight + 'px';
      ind.style.opacity = 1;
    }
  }
  function tabIndex(a) {
    var links = Array.prototype.slice.call(document.querySelectorAll('.sidebar-menu a[data-value]'));
    return links.indexOf(a);
  }
  document.addEventListener('DOMContentLoaded', function () {
    moveIndicator();
    setTimeout(moveIndicator, 400);
    setTimeout(moveIndicator, 1200);
    window.addEventListener('resize', moveIndicator);
    var ul = document.querySelector('.sidebar-menu');
    if (ul) {
      new MutationObserver(moveIndicator).observe(ul, { attributes: true, subtree: true, attributeFilter: ['class'] });
    }
    document.body.setAttribute('data-dir', 'fwd');
    document.addEventListener('click', function (e) {
      var a = e.target.closest && e.target.closest('.sidebar-menu a[data-value]');
      if (!a) return;
      var cur = document.querySelector('.sidebar-menu li.active a[data-value]');
      var from = cur ? tabIndex(cur) : 0, to = tabIndex(a);
      document.body.setAttribute('data-dir', to < from ? 'back' : 'fwd');
    }, true);
  });

  /* ---------- DataTables: re-measure widths once animations settle ---------- */
  function fixTables() {
    if (!window.jQuery || !jQuery.fn.dataTable) return;
    setTimeout(function () {
      try { jQuery.fn.dataTable.tables({ visible: true, api: true }).columns.adjust(); } catch (e) {}
    }, 750);
  }
  document.addEventListener('DOMContentLoaded', function () {
    if (window.jQuery) {
      jQuery(document).on('shiny:value shiny:visualchange', fixTables);
      jQuery(document).on('click', '.sidebar-menu a[data-value]', fixTables);
    }
    window.addEventListener('resize', fixTables);
  });

  /* ---------- 4. ripple ---------- */
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('.btn');
    if (!b) return;
    var r = b.getBoundingClientRect();
    var size = Math.max(r.width, r.height);
    var s = document.createElement('span');
    s.className = 'ripple';
    s.style.width = s.style.height = size + 'px';
    s.style.left = (e.clientX - r.left - size / 2) + 'px';
    s.style.top = (e.clientY - r.top - size / 2) + 'px';
    b.appendChild(s);
    setTimeout(function () { s.remove(); }, 700);
  });

  /* ---------- 5. tilt + hero spotlight ---------- */
  document.addEventListener('mousemove', function (e) {
    var t = e.target.closest && e.target.closest('.tilt');
    if (t) {
      var r = t.getBoundingClientRect();
      var px = (e.clientX - r.left) / r.width - 0.5, py = (e.clientY - r.top) / r.height - 0.5;
      t.style.setProperty('--rx', (-py * 7).toFixed(2) + 'deg');
      t.style.setProperty('--ry', (px * 9).toFixed(2) + 'deg');
    }
    var h = e.target.closest && e.target.closest('.hero');
    if (h) {
      var hr = h.getBoundingClientRect();
      h.style.setProperty('--mx', (e.clientX - hr.left) + 'px');
      h.style.setProperty('--my', (e.clientY - hr.top) + 'px');
    }
  });
  document.addEventListener('mouseout', function (e) {
    var t = e.target.closest && e.target.closest('.tilt');
    if (t && !t.contains(e.relatedTarget)) {
      t.style.setProperty('--rx', '0deg');
      t.style.setProperty('--ry', '0deg');
    }
  });

  /* ---------- 6. confetti ---------- */
  function confetti() {
    var c = document.getElementById('confetti');
    if (!c) { c = document.createElement('canvas'); c.id = 'confetti'; document.body.appendChild(c); }
    var ctx = c.getContext('2d');
    c.width = window.innerWidth; c.height = window.innerHeight;
    var colors = ['#6366F1', '#8B5CF6', '#06B6D4', '#10B981', '#F59E0B', '#F472B6'];
    var parts = [];
    for (var i = 0; i < 140; i++) {
      parts.push({
        x: c.width / 2 + (Math.random() - 0.5) * 160, y: c.height * 0.38,
        vx: (Math.random() - 0.5) * 15, vy: -Math.random() * 15 - 4,
        w: 6 + Math.random() * 6, h: 4 + Math.random() * 5,
        r: Math.random() * 6.28, vr: (Math.random() - 0.5) * 0.4,
        col: colors[i % colors.length]
      });
    }
    var t0 = performance.now();
    (function frame(now) {
      var el = now - t0;
      ctx.clearRect(0, 0, c.width, c.height);
      parts.forEach(function (p) {
        p.vy += 0.38; p.x += p.vx; p.y += p.vy; p.vx *= 0.99; p.r += p.vr;
        ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.r);
        ctx.globalAlpha = Math.max(0, 1 - el / 3200);
        ctx.fillStyle = p.col; ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
        ctx.restore();
      });
      if (el < 3200) requestAnimationFrame(frame); else ctx.clearRect(0, 0, c.width, c.height);
    })(t0);
  }
  function register() {
    if (window.Shiny && Shiny.addCustomMessageHandler) {
      Shiny.addCustomMessageHandler('confetti', function () { confetti(); });
    }
  }
  register();
  document.addEventListener('DOMContentLoaded', register);
})();
